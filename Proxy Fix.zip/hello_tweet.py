import tweepy

# enter your authentication details below (see dev.twitter.com)	
consumer_key = 'Xx17bybL1HR8PZTkdbb1wEwee'
consumer_secret = '18ApOPaaKvh66sy1ReWOTCiy4QKPkJJQWrspStvi94ZmdaOsew'
access_token = '118917652-y6Lfa9ppooZ622lOelJkmdRrH7aBegD31wvKxC8B'
access_token_secret = 'lFp0N4rRn0qgNfNGb94FOAeUXW2gMvqW4FwvqUQmSyWUa'

auth = tweepy.OAuthHandler(consumer_key, consumer_secret)
auth.set_access_token(access_token,access_token_secret)

api = tweepy.API(auth)

tweet = raw_input ( "#NBED Tweepy Test: ")

print "Sending tweet ", tweet
api.update_status('Tweet via python #CodeSaints: ' + tweet)

